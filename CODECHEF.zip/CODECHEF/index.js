const express = require('express');
const { v4: uuidv4 } = require('uuid');
const app = express();
const PORT = 3000;

// FIX: Replaced body-parser with the modern, built-in Express JSON parser
// app.use(bodyParser.json()); // Removed old line
app.use(express.json()); // New line for robust JSON body parsing

// --- 1. GLOBAL IN-MEMORY STATE ---
const state = {
    rooms: {},
    players: {},
};

// Helper function to shuffle an array (for role assignment)
const shuffle = (array) => {
    for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]];
    }
    return array;
};

// Score constants
const SCORES = { Raja: 1000, Mantri: 800, Sipahi: 500, Chor: 0 };


// --- 2. API ENDPOINTS ---

// Root route (Fixes the "Cannot GET /" error)
app.get('/', (req, res) => {
    res.send('Raja-Mantri-Chor-Sipahi Backend Server is Running! Use Postman for API calls.');
});


/**
 * Endpoint: POST /room/create
 * Creates a new room and sets the caller as Player 1.
 */
app.post('/room/create', (req, res) => {
    const { playerName } = req.body;
    if (!playerName) {
        return res.status(400).send({ error: "Player name is required." });
    }

    const roomId = uuidv4();
    const playerId = uuidv4();

    state.players[playerId] = {
        playerId,
        name: playerName,
        roomId,
        role: null,
        cumulativeScore: 0,
    };

    state.rooms[roomId] = {
        roomId,
        status: 'WAITING',
        players: [playerId], // Array of player IDs
        roles: {},
        mantriId: null,
        mantriGuess: null,
        results: null,
    };

    console.log(`Room created: ${roomId} by ${playerName}`);
    res.send({ roomId, playerId, playerName });
});

/**
 * Endpoint: POST /room/join
 * Allows a player to join an existing room.
 */
app.post('/room/join', (req, res) => {
    const { roomId, playerName } = req.body;
    const room = state.rooms[roomId];

    if (!room) {
        return res.status(404).send({ error: "Room not found." });
    }

    if (room.players.length >= 4) {
        return res.status(403).send({ error: "Room is full (max 4 players)." });
    }

    const playerId = uuidv4();

    state.players[playerId] = {
        playerId,
        name: playerName,
        roomId,
        role: null,
        cumulativeScore: 0,
    };

    room.players.push(playerId);
    
    console.log(`${playerName} joined room ${roomId}. Players: ${room.players.length}/4`);
    res.send({ roomId, playerId, playerName });
});

/**
 * Endpoint: POST /room/assign/:roomId
 * Randomly assigns roles once the room is full.
 */
app.post('/room/assign/:roomId', (req, res) => {
    const { roomId } = req.params;
    const room = state.rooms[roomId];

    if (!room) {
        return res.status(404).send({ error: "Room not found." });
    }
    if (room.players.length !== 4) {
        return res.status(403).send({ error: `Waiting for ${4 - room.players.length} more players.` });
    }
    if (room.status !== 'WAITING') {
        return res.status(400).send({ error: "Roles already assigned or game in progress." });
    }

    // 1. Prepare roles and shuffle them
    const roles = ['Raja', 'Mantri', 'Chor', 'Sipahi'];
    const shuffledRoles = shuffle([...roles]);
    
    let mantriId = null;

    // 2. Assign roles to players
    room.players.forEach((playerId, index) => {
        const role = shuffledRoles[index];
        room.roles[playerId] = role;
        state.players[playerId].role = role;

        if (role === 'Mantri') {
            mantriId = playerId;
        }
    });

    // 3. Update room state
    room.mantriId = mantriId;
    room.status = 'PLAYING';
    
    console.log(`Roles assigned in room ${roomId}. Mantri ID: ${mantriId}`);
    res.send({ success: true, status: room.status });
});

/**
 * Endpoint: GET /role/me/:roomId/:playerId
 * Returns the player's assigned role.
 */
app.get('/role/me/:roomId/:playerId', (req, res) => {
    const { roomId, playerId } = req.params;
    const player = state.players[playerId];
    const room = state.rooms[roomId];

    if (!player || player.roomId !== roomId) {
        return res.status(404).send({ error: "Player not found in this room." });
    }
    if (!room || room.status !== 'PLAYING') {
         return res.status(400).send({ error: "Roles not yet assigned." });
    }

    res.send({ role: player.role });
});

/**
 * Endpoint: POST /guess/:roomId
 * Allows the Mantri to submit their guess for the Chor.
 */
app.post('/guess/:roomId', (req, res) => {
    const { roomId } = req.params;
    // req.body should now be correctly parsed thanks to express.json()
    const { playerId, guessedPlayerId } = req.body; 
    const room = state.rooms[roomId];

    if (!room) {
        return res.status(404).send({ error: "Room not found." });
    }
    if (room.status !== 'PLAYING') {
        return res.status(400).send({ error: "Game is not in the guessing phase." });
    }

    if (room.mantriId !== playerId || state.players[playerId].role !== 'Mantri') {
        return res.status(403).send({ error: "Only the Mantri can submit a guess." });
    }

    if (playerId === guessedPlayerId) {
        return res.status(400).send({ error: "Mantri cannot guess themselves." });
    }

    room.mantriGuess = guessedPlayerId;
    room.status = 'RESULTS'; 

    console.log(`Mantri (${state.players[playerId].name}) guessed player ID: ${guessedPlayerId}`);
    res.send({ success: true, message: "Guess submitted. Results are ready." });
});

/**
 * Endpoint: GET /result/:roomId
 * Reveals roles and calculates points for the round.
 */
app.get('/result/:roomId', (req, res) => {
    const { roomId } = req.params;
    const room = state.rooms[roomId];

    if (!room) {
        return res.status(404).send({ error: "Room not found." });
    }
    if (room.status !== 'RESULTS') {
        return res.status(400).send({ error: "Results are not ready. Mantri must submit a guess." });
    }
    
    const results = {};
    let actualChorId = null;

    // 1. Find the actual Chor
    for (const playerId of room.players) {
        if (room.roles[playerId] === 'Chor') {
            actualChorId = playerId;
            break;
        }
    }

    const isGuessCorrect = room.mantriGuess === actualChorId;

    // 2. Calculate scores for each player
    room.players.forEach(playerId => {
        const role = room.roles[playerId];
        let score = SCORES[role]; // Start with base score

        if (!isGuessCorrect) {
            // Logic for INCORRECT guess: Mantri loses 800, Chor gains 800
            if (role === 'Mantri') {
                score = 0; // Mantri loses all points
            } else if (role === 'Chor') {
                score = SCORES.Mantri; // Chor steals Mantri's 800 points
            }
            // Raja (1000) and Sipahi (500) keep their base scores in this case.
        } 
        
        results[state.players[playerId].name] = {
            role: role,
            score: score
        };

        // Update cumulative score
        state.players[playerId].cumulativeScore += score;
    });

    console.log(`Room ${roomId} results calculated. Mantri was ${isGuessCorrect ? 'CORRECT' : 'INCORRECT'}.`);
    res.send({ success: true, results: results });
});

/**
 * Endpoint: POST /room/reset/:roomId
 * Resets the room status and roles to start a new round.
 */
app.post('/room/reset/:roomId', (req, res) => {
    const { roomId } = req.params;
    const room = state.rooms[roomId];

    if (!room) {
        return res.status(404).send({ error: "Room not found." });
    }

    // Reset the necessary state variables for a new round
    room.status = 'WAITING'; // Set back to waiting for assignment
    room.roles = {};
    room.mantriId = null;
    room.mantriGuess = null;
    room.results = null;

    room.players.forEach(playerId => {
        state.players[playerId].role = null;
    });

    console.log(`Room ${roomId} reset for a new round.`);
    res.send({ success: true, status: room.status });
});

/**
 * Endpoint: GET /leaderboard/:roomId
 * Returns the cumulative scores for all players in the room, sorted high to low.
 */
app.get('/leaderboard/:roomId', (req, res) => {
    const { roomId } = req.params;
    const room = state.rooms[roomId];

    if (!room) {
        return res.status(404).send({ error: "Room not found." });
    }

    const leaderboard = room.players.map(playerId => {
        const player = state.players[playerId];
        return {
            name: player.name,
            score: player.cumulativeScore
        };
    });

    leaderboard.sort((a, b) => b.score - a.score);

    res.send({ success: true, leaderboard: leaderboard });
});


// --- 3. START THE SERVER ---
app.listen(PORT, () => {
    console.log(`Raja Mantri backend running on http://localhost:${PORT}`);
});